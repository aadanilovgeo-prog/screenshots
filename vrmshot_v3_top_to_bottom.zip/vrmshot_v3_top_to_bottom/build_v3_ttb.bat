@echo off
setlocal
where gcc >nul 2>nul
if errorlevel 1 (
  echo [ERROR] gcc not found. Run from w64devkit terminal.
  pause & exit /b 1
)
echo [1/2] Resources...
windres vrmshot_v3_ttb.rc -o vrmshot_v3_ttb_res.o
if errorlevel 1 ( echo [ERROR] windres failed. & pause & exit /b 1 )
echo [2/2] Compiling...
gcc -O2 -o vrmshot_v3_top_to_bottom.exe vrmshot_v3_top_to_bottom.c vrmshot_v3_ttb_res.o -lgdi32 -luser32 -lcomctl32 -mwindows -static
if errorlevel 1 ( echo [ERROR] gcc failed. & pause & exit /b 1 )
echo.
echo Done: vrmshot_v3_top_to_bottom.exe
pause
