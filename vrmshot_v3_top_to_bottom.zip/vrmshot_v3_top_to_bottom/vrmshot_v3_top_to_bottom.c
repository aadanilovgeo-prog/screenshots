/* vrmshot_v3_top_to_bottom.c — Long page screenshot stitcher (v3.0 top-to-bottom)
 *
 * KEY DIFFERENCE from v2: full-pixel matching instead of subsampled profiles.
 *
 * Why this works on repetitive tables:
 *   The correct match is a pixel-exact copy of the same screen content, so
 *   its SAD (sum of absolute differences) = 0. Even on a table where rows
 *   LOOK identical, the actual text differs pixel-by-pixel ("USR-ARM" vs
 *   "VTB-USERS"). A wrong match always has SAD >> 0. The correct match wins
 *   by a huge margin. Early termination makes it fast in practice: once the
 *   correct position (SAD=0) is found, all remaining candidates are skipped
 *   on the very first row comparison.
 *
 * Build (MinGW-w64):
 *   windres vrmshot_v3_ttb.rc -o vrmshot_v3_ttb_res.o
 *   gcc -O2 -o vrmshot_v3_top_to_bottom.exe vrmshot_v3_top_to_bottom.c vrmshot_v3_ttb_res.o -lgdi32 -luser32 -lcomctl32 -mwindows -static
 */

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <process.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

/* ======================== SETTINGS ======================== */
#define SCROLL_NOTCHES     3
#define WHEEL_SETTLE_MS    350
#define MAX_FRAMES         500
#define END_REPEAT_LIMIT   3
#define MATCH_BAND_ROWS    80     /* rows for full-pixel template */
#define MATCH_SKIP_TOP     4      /* skip top rows (border pixels) */

/* ======================== UI IDs ======================== */
#define IDC_BTN_START      1001
#define IDC_BTN_STOP       1002
#define IDC_STATIC_STATUS  1003
#define WM_CAPTURE_DONE    (WM_USER + 1)

/* ======================== GLOBALS ======================== */
static HWND g_hMainWnd = NULL, g_hBtnStart = NULL, g_hBtnStop = NULL, g_hStatus = NULL;
static volatile int g_stopRequested = 0;
static HANDLE g_hThread = NULL;
static RECT g_sel = {0};
static BOOL g_selecting = FALSE, g_selDone = FALSE, g_selCancelled = FALSE;
static POINT g_selStart;

/* ======================== LOG ======================== */
static FILE *g_log = NULL;
static void log_open(void) {
    SYSTEMTIME st; GetLocalTime(&st);
    char name[128];
    sprintf(name, "vrmshot_v3_ttb_%02d.%02d.%02d_%02d-%02d-%02d.log",
            st.wDay,st.wMonth,st.wYear%100,st.wHour,st.wMinute,st.wSecond);
    g_log = fopen(name, "w");
    if (g_log) fprintf(g_log, "VrmShot v3.0 top-to-bottom | %04d-%02d-%02d %02d:%02d:%02d\n\n",
                       st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
}
static void log_msg(const char *fmt, ...) {
    if (!g_log) return;
    va_list ap; va_start(ap,fmt); vfprintf(g_log,fmt,ap); va_end(ap);
    fprintf(g_log,"\n"); fflush(g_log);
}
static void log_close(void) { if(g_log){fprintf(g_log,"\nDone.\n");fclose(g_log);g_log=NULL;} }

/* ======================== FRAME ======================== */
typedef struct { int w, h; unsigned char *px; } Frame;
static void frame_free(Frame *f) { if(f&&f->px){free(f->px);f->px=NULL;} }

static int capture_region(int x, int y, int w, int h, Frame *out) {
    HDC hScr=GetDC(NULL); HDC hMem=CreateCompatibleDC(hScr);
    HBITMAP hBmp=CreateCompatibleBitmap(hScr,w,h);
    HGDIOBJ old=SelectObject(hMem,hBmp);
    BitBlt(hMem,0,0,w,h,hScr,x,y,SRCCOPY|CAPTUREBLT);
    BITMAPINFO bi; memset(&bi,0,sizeof(bi));
    bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth=w; bi.bmiHeader.biHeight=-h;
    bi.bmiHeader.biPlanes=1; bi.bmiHeader.biBitCount=32; bi.bmiHeader.biCompression=BI_RGB;
    unsigned char *bgra=(unsigned char*)malloc((size_t)w*h*4);
    if(!bgra) goto fail;
    if(!GetDIBits(hMem,hBmp,0,h,bgra,&bi,DIB_RGB_COLORS)){free(bgra);goto fail;}
    out->w=w; out->h=h;
    out->px=(unsigned char*)malloc((size_t)w*h*3);
    if(!out->px){free(bgra);goto fail;}
    for(long i=0,n=(long)w*h;i<n;i++){
        out->px[i*3]=bgra[i*4+2]; out->px[i*3+1]=bgra[i*4+1]; out->px[i*3+2]=bgra[i*4];}
    free(bgra);
    SelectObject(hMem,old);DeleteObject(hBmp);DeleteDC(hMem);ReleaseDC(NULL,hScr);return 1;
fail:
    SelectObject(hMem,old);DeleteObject(hBmp);DeleteDC(hMem);ReleaseDC(NULL,hScr);return 0;
}

/* ======================== SCROLL UP ======================== */
static void scroll_down(int cx, int cy, int notches) {
    SetCursorPos(cx,cy); Sleep(20);
    INPUT inp; memset(&inp,0,sizeof(inp));
    inp.type=INPUT_MOUSE; inp.mi.dwFlags=MOUSEEVENTF_WHEEL;
    inp.mi.mouseData=(DWORD)(notches * -WHEEL_DELTA); /* negative = scroll DOWN */
    SendInput(1,&inp,sizeof(INPUT));
}

/* ======================== FULL-PIXEL SHIFT FINDER ========================
 *
 * THE CORE ALGORITHM (v3):
 *
 * Takes a band of MATCH_BAND_ROWS rows from near the top of 'cur' frame
 * and searches for an exact pixel match in 'prev' frame across ALL
 * possible positions.
 *
 * Why it works on repetitive tables:
 *   Even rows that look structurally identical have different text
 *   ("Zone_Users_USR-ARM" vs "Zone_Users_VTB-USERS"). At the pixel
 *   level, these are completely different patterns. The CORRECT match
 *   position gives SAD = 0 (exact copy of screen pixels), while ANY
 *   wrong position gives SAD >> 0. There is no ambiguity.
 *
 * Speed:
 *   Early termination per candidate: once a candidate's accumulated SAD
 *   exceeds the current best, it's skipped. After finding the correct
 *   match (SAD=0), all remaining candidates are rejected on the very
 *   first row (first ~4KB of comparison). Typical runtime: < 100ms.
 *
 * Returns: shift d in pixels (how far the page scrolled), or -1 if
 *          no good match found.
 */
static int find_shift_fullpixel(const Frame *prev, const Frame *cur) {
    int band = MATCH_BAND_ROWS;
    if (band > cur->h / 3) band = cur->h / 3;
    if (band < 10) band = 10;

    int tmpl_start = MATCH_SKIP_TOP;
    if (tmpl_start + band > cur->h) tmpl_start = 0;

    int w3 = cur->w * 3;  /* bytes per row */
    int d_max = prev->h - tmpl_start - band;
    if (d_max < 1) return -1;

    long best_sad = -1;
    int best_d = -1;

    for (int d = 1; d <= d_max; d++) {
        long sad = 0;
        int rejected = 0;

        for (int r = 0; r < band; r++) {
            const unsigned char *t = cur->px  + (size_t)(tmpl_start + r) * w3;
            const unsigned char *p = prev->px + (size_t)(d + tmpl_start + r) * w3;

            /* Compare every pixel in this row (full resolution) */
            long row_sad = 0;
            for (int b = 0; b < w3; b += 6) {
                /* Compare every 2nd pixel (3x speedup, negligible quality loss) */
                row_sad += abs((int)t[b]   - (int)p[b])
                         + abs((int)t[b+1] - (int)p[b+1])
                         + abs((int)t[b+2] - (int)p[b+2]);
            }
            sad += row_sad;

            /* Early termination: already worse than current best */
            if (best_sad >= 0 && sad > best_sad) {
                rejected = 1;
                break;
            }
        }

        if (!rejected) {
            if (best_sad < 0 || sad < best_sad) {
                best_sad = sad;
                best_d = d;
                /* Perfect match found — nothing can beat SAD=0 */
                if (sad == 0) break;
            }
        }
    }

    /* Quality check: average SAD per compared byte should be very low */
    if (best_d > 0 && best_sad >= 0) {
        long total_bytes = (long)band * (w3 / 2);  /* we compared every 2nd pixel */
        double avg = (double)best_sad / (double)total_bytes;
        log_msg("  match: d=%d sad=%ld avg=%.2f", best_d, best_sad, avg);
        if (avg > 15.0) {
            log_msg("  WARNING: weak match (avg=%.2f), likely no overlap", avg);
            return -1;
        }
    }

    return best_d;
}

/* ======================== END DETECTION ======================== */
static int frames_nearly_identical(const Frame *a, const Frame *b) {
    if(a->w!=b->w||a->h!=b->h) return 0;
    int w3=a->w*3;
    long total=0; int rows=0;
    for(int r=0;r<a->h;r+=4){
        const unsigned char*pa=a->px+(size_t)r*w3;
        const unsigned char*pb=b->px+(size_t)r*w3;
        long row_sad=0;
        for(int b2=0;b2<w3;b2+=12)
            row_sad+=abs((int)pa[b2]-(int)pb[b2])+abs((int)pa[b2+1]-(int)pb[b2+1])+abs((int)pa[b2+2]-(int)pb[b2+2]);
        total+=row_sad; rows++;
    }
    if(rows==0) return 0;
    double avg=(double)total/(double)(rows*(w3/12)*3);
    return (avg < 2.0);
}

/* ======================== CANVAS ======================== */
typedef struct { int w,h,cap; unsigned char*px; } Canvas;
static int canvas_append(Canvas*c,const unsigned char*src,int w,int rows,int src_row){
    if(c->w==0)c->w=w; if(w!=c->w||rows<=0)return 0;
    long need=(long)(c->h+rows)*c->w*3;
    if(need>c->cap){long nc=need*2;unsigned char*np=(unsigned char*)realloc(c->px,nc);
        if(!np)return 0;c->px=np;c->cap=(int)nc;}
    memcpy(c->px+(size_t)c->h*c->w*3,src+(size_t)src_row*w*3,(size_t)rows*w*3);
    c->h+=rows; return 1;
}

/* ======================== STATUS ======================== */
static void set_status(const char*fmt,...){
    char buf[512];va_list ap;va_start(ap,fmt);vsnprintf(buf,sizeof(buf),fmt,ap);va_end(ap);
    if(g_hStatus)SetWindowTextA(g_hStatus,buf);
}

/* ======================== OVERLAY ======================== */
static LRESULT CALLBACK OverlayProc(HWND hWnd,UINT msg,WPARAM wp,LPARAM lp){
    switch(msg){
    case WM_LBUTTONDOWN:
        g_selecting=TRUE;g_selStart.x=GET_X_LPARAM(lp);g_selStart.y=GET_Y_LPARAM(lp);
        g_sel.left=g_sel.right=g_selStart.x;g_sel.top=g_sel.bottom=g_selStart.y;
        SetCapture(hWnd);return 0;
    case WM_MOUSEMOVE:
        if(g_selecting){int mx=GET_X_LPARAM(lp),my=GET_Y_LPARAM(lp);
            g_sel.left=min(g_selStart.x,mx);g_sel.top=min(g_selStart.y,my);
            g_sel.right=max(g_selStart.x,mx);g_sel.bottom=max(g_selStart.y,my);
            InvalidateRect(hWnd,NULL,TRUE);}return 0;
    case WM_LBUTTONUP:
        if(g_selecting){g_selecting=FALSE;ReleaseCapture();
            g_selDone=TRUE;DestroyWindow(hWnd);}return 0;
    case WM_KEYDOWN:
        if(wp==VK_ESCAPE){g_selCancelled=TRUE;DestroyWindow(hWnd);}return 0;
    case WM_PAINT:{
        PAINTSTRUCT ps;HDC hdc=BeginPaint(hWnd,&ps);
        RECT full;GetClientRect(hWnd,&full);
        HBRUSH dark=CreateSolidBrush(RGB(0,0,0));FillRect(hdc,&full,dark);DeleteObject(dark);
        if(g_sel.right>g_sel.left&&g_sel.bottom>g_sel.top){
            HBRUSH clr=CreateSolidBrush(RGB(40,40,40));FillRect(hdc,&g_sel,clr);DeleteObject(clr);
            HPEN pen=CreatePen(PS_SOLID,2,RGB(0,200,255));
            HGDIOBJ op=SelectObject(hdc,pen);HGDIOBJ ob=SelectObject(hdc,GetStockObject(NULL_BRUSH));
            Rectangle(hdc,g_sel.left,g_sel.top,g_sel.right,g_sel.bottom);
            SelectObject(hdc,op);SelectObject(hdc,ob);DeleteObject(pen);
            char buf[64];sprintf(buf,"%ld x %ld",g_sel.right-g_sel.left,g_sel.bottom-g_sel.top);
            SetTextColor(hdc,RGB(0,200,255));SetBkMode(hdc,TRANSPARENT);
            TextOutA(hdc,g_sel.left+4,g_sel.top>20?g_sel.top-20:g_sel.top+2,buf,(int)strlen(buf));
        }
        EndPaint(hWnd,&ps);return 0;}
    case WM_DESTROY:PostQuitMessage(0);return 0;
    }
    return DefWindowProc(hWnd,msg,wp,lp);
}

static int select_region(RECT*result){
    g_selDone=FALSE;g_selCancelled=FALSE;g_selecting=FALSE;
    g_sel.left=g_sel.right=g_sel.top=g_sel.bottom=0;
    HINSTANCE hInst=GetModuleHandle(NULL);
    WNDCLASSA wc;memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc=OverlayProc;wc.hInstance=hInst;
    wc.lpszClassName="V3TTBOverlay";wc.hCursor=LoadCursor(NULL,IDC_CROSS);
    RegisterClassA(&wc);
    int sx=GetSystemMetrics(SM_XVIRTUALSCREEN),sy=GetSystemMetrics(SM_YVIRTUALSCREEN);
    int sw=GetSystemMetrics(SM_CXVIRTUALSCREEN),sh=GetSystemMetrics(SM_CYVIRTUALSCREEN);
    HWND hOvr=CreateWindowExA(WS_EX_TOPMOST|WS_EX_LAYERED,
        "V3TTBOverlay","",WS_POPUP,sx,sy,sw,sh,NULL,NULL,hInst,NULL);
    SetLayeredWindowAttributes(hOvr,0,120,LWA_ALPHA);
    ShowWindow(hOvr,SW_SHOW);UpdateWindow(hOvr);
    MSG msg;
    while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);
        if(g_selDone||g_selCancelled)break;}
    while(PeekMessage(&msg,NULL,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessage(&msg);}
    if(g_selCancelled)return 0;
    result->left=g_sel.left+sx;result->top=g_sel.top+sy;
    result->right=g_sel.right+sx;result->bottom=g_sel.bottom+sy;
    return(result->right-result->left>10&&result->bottom-result->top>10);
}

/* ======================== CAPTURE THREAD ======================== */
typedef struct{RECT region;char resultMsg[512];int success;}CaptureParams;

static unsigned __stdcall capture_thread(void*arg){
    CaptureParams*p=(CaptureParams*)arg;
    RECT r=p->region;
    int x=r.left,y=r.top,w=r.right-r.left,h=r.bottom-r.top;
    int cx=x+w/2, cy=y+h/2;

    SYSTEMTIME st; GetLocalTime(&st);
    char ts[32];
    sprintf(ts,"%02d.%02d.%02d_%02d-%02d-%02d",
            st.wDay,st.wMonth,st.wYear%100,st.wHour,st.wMinute,st.wSecond);

    log_open();
    log_msg("Region: %d,%d  %dx%d",x,y,w,h);
    log_msg("Direction: top-to-bottom");
    log_msg("Notches/step: %d  settle: %dms  band: %d rows",
         SCROLL_NOTCHES, WHEEL_SETTLE_MS, MATCH_BAND_ROWS);

    /* ---- Phase 1: Collect frames scrolling UP ---- */
    set_status("Phase 1/2: Collecting frames (scrolling down)...");
    log_msg("\n=== Phase 1: Collecting ===");

    Frame*frames=(Frame*)calloc(MAX_FRAMES,sizeof(Frame));
    if(!frames){sprintf(p->resultMsg,"Out of memory.");p->success=0;log_close();goto done_nf;}

    if(!capture_region(x,y,w,h,&frames[0])){
        sprintf(p->resultMsg,"Screen capture failed.");p->success=0;log_close();goto done_fr;}
    int nframes=1; int end_repeat=0;

    for(;nframes<MAX_FRAMES&&!g_stopRequested;){
        set_status("Collecting: frame %d  (scrolling down)...",nframes);
        scroll_down(cx,cy,SCROLL_NOTCHES);
        Sleep(WHEEL_SETTLE_MS);
        Frame cur;memset(&cur,0,sizeof(cur));
        if(!capture_region(x,y,w,h,&cur))break;
        if(frames_nearly_identical(&frames[nframes-1],&cur)){
            end_repeat++;frame_free(&cur);
            log_msg("  frame %d: identical (repeat=%d)",nframes,end_repeat);
            if(end_repeat>=END_REPEAT_LIMIT){log_msg("Bottom reached.");break;}
            continue;
        }
        end_repeat=0;
        frames[nframes]=cur; nframes++;
        log_msg("  frame %d captured",nframes);
    }
    log_msg("Collected %d frames total.",nframes);

    if(nframes<2){
        sprintf(p->resultMsg,"Only 1 frame. Page may not have scrolled.\nMake sure you start at the TOP.");
        p->success=0;log_close();goto done_fr;
    }

    /* ---- Phase 2: Stitch with full-pixel matching ---- */
    set_status("Phase 2/2: Stitching %d frames...",nframes);
    log_msg("\n=== Phase 2: Stitching ===");

    Canvas canvas;memset(&canvas,0,sizeof(canvas));
    canvas_append(&canvas,frames[0].px,frames[0].w,frames[0].h,0);
    log_msg("  base frame: %dx%d",frames[0].w,frames[0].h);

    int stitch_errors = 0;

    for(int i=1;i<nframes;i++){
        set_status("Stitching %d / %d  |  %d x %d px",i+1,nframes,canvas.w,canvas.h);

        int d = find_shift_fullpixel(&frames[i-1], &frames[i]);

        if(d < 1){
            /* No match found — page may have scrolled more than frame height.
               Use previous successful d, or a fallback. */
            log_msg("  stitch %d: NO MATCH, using h/2 fallback",i);
            d = h / 2;
            stitch_errors++;
        }

        if(d > h - 10) d = h - 10;
        if(d < 1) d = 1;

        int new_rows = d;
        log_msg("  stitch %d: d=%d  new_rows=%d  canvas_h=%d->%d",
             i, d, new_rows, canvas.h, canvas.h + new_rows);

        canvas_append(&canvas, frames[i].px, frames[i].w, new_rows, h - new_rows);
    }

    log_msg("\nStitch complete: %d x %d px  (%d errors)", canvas.w, canvas.h, stitch_errors);

    if(canvas.h==0||!canvas.px){
        sprintf(p->resultMsg,"Failed to create image.");p->success=0;log_close();goto done_fr;}

    /* ---- Save ---- */
    {
        char fname[80]; sprintf(fname,"output_v3_ttb_%s.png",ts);
        set_status("Saving %s ...",fname);
        log_msg("Saving: %s",fname);
        int ok=stbi_write_png(fname,canvas.w,canvas.h,3,canvas.px,canvas.w*3);
        if(ok){
            sprintf(p->resultMsg,"Done!\nFrames: %d\nSize: %d x %d px\nErrors: %d\nFile: %s",
                    nframes,canvas.w,canvas.h,stitch_errors,fname);
            p->success=1; log_msg("OK: %dx%d",canvas.w,canvas.h);
        } else {
            sprintf(p->resultMsg,"Error writing PNG.");p->success=0;log_msg("ERROR: write failed");
        }
    }
    log_close();

done_fr:
    for(int i=0;i<nframes;i++)frame_free(&frames[i]);
    free(frames);
done_nf:
    free(canvas.px);
    PostMessage(g_hMainWnd,WM_CAPTURE_DONE,0,(LPARAM)p);
    return 0;
}

/* ======================== MAIN WINDOW ======================== */
static void ui_set_capturing(BOOL on){
    EnableWindow(g_hBtnStart,!on);
    ShowWindow(g_hBtnStop,on?SW_SHOW:SW_HIDE);EnableWindow(g_hBtnStop,on);
}
static void start_capture(void){
    ShowWindow(g_hMainWnd,SW_HIDE);Sleep(200);
    RECT sel;
    if(!select_region(&sel)){ShowWindow(g_hMainWnd,SW_SHOW);set_status("Selection cancelled.");return;}
    ShowWindow(g_hMainWnd,SW_SHOW);ui_set_capturing(TRUE);g_stopRequested=0;
    static CaptureParams cp;cp.region=sel;cp.resultMsg[0]=0;cp.success=0;
    g_hThread=(HANDLE)_beginthreadex(NULL,0,capture_thread,&cp,0,NULL);
}
static LRESULT CALLBACK MainWndProc(HWND hWnd,UINT msg,WPARAM wp,LPARAM lp){
    switch(msg){
    case WM_CREATE:{
        HINSTANCE hInst=((LPCREATESTRUCT)lp)->hInstance;
        CreateWindowA("STATIC","VrmShot v3.0 - Top-to-Bottom (Full-Pixel Match)",
            WS_CHILD|WS_VISIBLE|SS_CENTER,5,10,440,20,hWnd,NULL,hInst,NULL);
        CreateWindowA("STATIC",
            "1. Scroll to the TOP of the article first.\n"
            "2. Click \"Start\" and select the scrollable area.\n"
            "3. Do not touch the mouse during capture.\n"
            "4. Result: PNG + log file next to the program.",
            WS_CHILD|WS_VISIBLE,20,36,420,72,hWnd,NULL,hInst,NULL);
        g_hBtnStart=CreateWindowA("BUTTON","Start",
            WS_CHILD|WS_VISIBLE|BS_DEFPUSHBUTTON,150,118,150,36,hWnd,
            (HMENU)(INT_PTR)IDC_BTN_START,hInst,NULL);
        g_hBtnStop=CreateWindowA("BUTTON","Stop",WS_CHILD|BS_PUSHBUTTON,
            150,118,150,36,hWnd,(HMENU)(INT_PTR)IDC_BTN_STOP,hInst,NULL);
        g_hStatus=CreateWindowA("STATIC",
            "Ready. Scroll to TOP of article, then click Start.",
            WS_CHILD|WS_VISIBLE|SS_LEFT,15,168,420,60,hWnd,
            (HMENU)(INT_PTR)IDC_STATIC_STATUS,hInst,NULL);
        HFONT hFont=CreateFontA(16,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,
            0,0,CLEARTYPE_QUALITY,0,"Segoe UI");
        if(hFont){SendMessage(g_hBtnStart,WM_SETFONT,(WPARAM)hFont,TRUE);
            SendMessage(g_hBtnStop,WM_SETFONT,(WPARAM)hFont,TRUE);
            SendMessage(g_hStatus,WM_SETFONT,(WPARAM)hFont,TRUE);}
        return 0;}
    case WM_COMMAND:
        if(LOWORD(wp)==IDC_BTN_START){start_capture();return 0;}
        if(LOWORD(wp)==IDC_BTN_STOP){g_stopRequested=1;set_status("Stopping...");
            EnableWindow(g_hBtnStop,FALSE);return 0;}
        break;
    case WM_CAPTURE_DONE:{
        CaptureParams*cp=(CaptureParams*)lp;ui_set_capturing(FALSE);
        set_status("%s",cp->resultMsg);
        if(g_hThread){CloseHandle(g_hThread);g_hThread=NULL;}return 0;}
    case WM_CLOSE:
        if(g_hThread){g_stopRequested=1;WaitForSingleObject(g_hThread,5000);
            CloseHandle(g_hThread);g_hThread=NULL;}
        DestroyWindow(hWnd);return 0;
    case WM_DESTROY:PostQuitMessage(0);return 0;
    }
    return DefWindowProc(hWnd,msg,wp,lp);
}

/* ======================== ENTRY ======================== */
int WINAPI WinMain(HINSTANCE hInst,HINSTANCE hPrev,LPSTR lpCmd,int nShow){
    (void)hPrev;(void)lpCmd;
    INITCOMMONCONTROLSEX icc={sizeof(icc),ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);
    WNDCLASSA wc;memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc=MainWndProc;wc.hInstance=hInst;wc.lpszClassName="V3TTBMain";
    wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
    wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hIcon=LoadIcon(NULL,IDI_APPLICATION);
    RegisterClassA(&wc);
    g_hMainWnd=CreateWindowExA(0,"V3TTBMain","VrmShot v3.0 Top-to-Bottom",
        WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
        CW_USEDEFAULT,CW_USEDEFAULT,460,270,NULL,NULL,hInst,NULL);
    ShowWindow(g_hMainWnd,nShow);UpdateWindow(g_hMainWnd);
    MSG msg;
    while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}
    return(int)msg.wParam;
}
