/* stb_image_write.h — минимальная самодостаточная реализация PNG-энкодера.
 *
 * Это НЕ оригинальный stb от Sean Barrett, а компактная замена с тем же
 * интерфейсом stbi_write_png(), достаточная для данной программы.
 * Public domain. Без внешних зависимостей (только стандартная libc).
 *
 * Особенности:
 *  - PNG, цвет RGB (8 бит/канал, тип 2) или RGBA (тип 6) или grey/grey+alpha.
 *  - Фильтр строк: None (0) на каждой строке.
 *  - DEFLATE: используется режим "stored" (несжатые блоки). Файл получается
 *    больше, чем при настоящем сжатии, но это полностью валидный PNG,
 *    открывается любым просмотрщиком.
 *
 * Интерфейс:
 *   int stbi_write_png(const char *filename, int w, int h, int comp,
 *                      const void *data, int stride_bytes);
 *   возвращает 1 при успехе, 0 при ошибке.
 */
#ifndef STB_IMAGE_WRITE_H_MINI
#define STB_IMAGE_WRITE_H_MINI

#ifdef __cplusplus
extern "C" {
#endif

int stbi_write_png(const char *filename, int w, int h, int comp,
                   const void *data, int stride_bytes);

#ifdef STB_IMAGE_WRITE_IMPLEMENTATION

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- CRC32 ---- */
static unsigned int stbi__crc_table[256];
static int stbi__crc_init_done = 0;
static void stbi__crc_init(void) {
    for (unsigned int n = 0; n < 256; n++) {
        unsigned int c = n;
        for (int k = 0; k < 8; k++)
            c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
        stbi__crc_table[n] = c;
    }
    stbi__crc_init_done = 1;
}
static unsigned int stbi__crc32(unsigned int crc, const unsigned char *buf, size_t len) {
    if (!stbi__crc_init_done) stbi__crc_init();
    crc = crc ^ 0xFFFFFFFFu;
    for (size_t i = 0; i < len; i++)
        crc = stbi__crc_table[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFFu;
}

/* ---- Adler32 (для zlib потока) ---- */
static unsigned int stbi__adler32(const unsigned char *data, size_t len) {
    unsigned int a = 1, b = 0;
    const unsigned int MOD = 65521u;
    size_t i = 0;
    while (len > 0) {
        size_t chunk = len > 5552 ? 5552 : len;
        for (size_t k = 0; k < chunk; k++) { a += data[i++]; b += a; }
        a %= MOD; b %= MOD;
        len -= chunk;
    }
    return (b << 16) | a;
}

/* ---- динамический буфер ---- */
typedef struct { unsigned char *p; size_t len, cap; } stbi__buf;
static int stbi__buf_ensure(stbi__buf *b, size_t add) {
    if (b->len + add <= b->cap) return 1;
    size_t nc = (b->cap ? b->cap * 2 : 4096);
    while (nc < b->len + add) nc *= 2;
    unsigned char *np = (unsigned char*)realloc(b->p, nc);
    if (!np) return 0;
    b->p = np; b->cap = nc;
    return 1;
}
static int stbi__put(stbi__buf *b, const void *src, size_t n) {
    if (!stbi__buf_ensure(b, n)) return 0;
    memcpy(b->p + b->len, src, n);
    b->len += n;
    return 1;
}
static int stbi__put_u8(stbi__buf *b, unsigned char v) { return stbi__put(b, &v, 1); }
static int stbi__put_u32be(stbi__buf *b, unsigned int v) {
    unsigned char t[4] = { (unsigned char)(v>>24),(unsigned char)(v>>16),
                           (unsigned char)(v>>8),(unsigned char)v };
    return stbi__put(b, t, 4);
}

/* ---- запись PNG chunk ---- */
static int stbi__chunk(stbi__buf *out, const char *type, const unsigned char *data, unsigned int len) {
    if (!stbi__put_u32be(out, len)) return 0;
    size_t crc_start = out->len;
    if (!stbi__put(out, type, 4)) return 0;
    if (len && !stbi__put(out, data, len)) return 0;
    unsigned int crc = stbi__crc32(0, out->p + crc_start, 4 + len);
    return stbi__put_u32be(out, crc);
}

int stbi_write_png(const char *filename, int w, int h, int comp,
                   const void *data, int stride_bytes) {
    if (w <= 0 || h <= 0 || comp < 1 || comp > 4 || !data) return 0;
    if (stride_bytes == 0) stride_bytes = w * comp;

    const unsigned char *pix = (const unsigned char*)data;

    /* 1) Сырые данные изображения с байтом фильтра (0) в начале каждой строки. */
    size_t raw_len = (size_t)h * (1 + (size_t)w * comp);
    unsigned char *raw = (unsigned char*)malloc(raw_len);
    if (!raw) return 0;
    {
        size_t o = 0;
        for (int y = 0; y < h; y++) {
            raw[o++] = 0; /* filter None */
            memcpy(raw + o, pix + (size_t)y * stride_bytes, (size_t)w * comp);
            o += (size_t)w * comp;
        }
    }

    /* 2) Оборачиваем в zlib-поток с DEFLATE stored-блоками. */
    stbi__buf z; memset(&z, 0, sizeof(z));
    /* zlib header: CMF=0x78, FLG=0x01 (no compression preset, проверка) */
    if (!stbi__put_u8(&z, 0x78) || !stbi__put_u8(&z, 0x01)) { free(raw); free(z.p); return 0; }

    size_t pos = 0;
    while (pos < raw_len) {
        size_t block = raw_len - pos;
        if (block > 65535) block = 65535;
        unsigned char final = (pos + block >= raw_len) ? 1 : 0;
        if (!stbi__put_u8(&z, final)) { free(raw); free(z.p); return 0; }
        unsigned short len16 = (unsigned short)block;
        unsigned short nlen = (unsigned short)(~len16);
        unsigned char le[4] = { (unsigned char)(len16&0xFF),(unsigned char)(len16>>8),
                                (unsigned char)(nlen&0xFF),(unsigned char)(nlen>>8) };
        if (!stbi__put(&z, le, 4)) { free(raw); free(z.p); return 0; }
        if (!stbi__put(&z, raw + pos, block)) { free(raw); free(z.p); return 0; }
        pos += block;
    }
    unsigned int adler = stbi__adler32(raw, raw_len);
    if (!stbi__put_u32be(&z, adler)) { free(raw); free(z.p); return 0; }
    free(raw);

    /* 3) Собираем PNG. */
    stbi__buf out; memset(&out, 0, sizeof(out));
    static const unsigned char sig[8] = {137,80,78,71,13,10,26,10};
    if (!stbi__put(&out, sig, 8)) { free(z.p); free(out.p); return 0; }

    /* IHDR */
    unsigned char ihdr[13];
    ihdr[0]=(unsigned char)(w>>24); ihdr[1]=(unsigned char)(w>>16);
    ihdr[2]=(unsigned char)(w>>8);  ihdr[3]=(unsigned char)w;
    ihdr[4]=(unsigned char)(h>>24); ihdr[5]=(unsigned char)(h>>16);
    ihdr[6]=(unsigned char)(h>>8);  ihdr[7]=(unsigned char)h;
    ihdr[8]=8; /* bit depth */
    /* color type: 1->0 grey, 2->4 grey+alpha, 3->2 rgb, 4->6 rgba */
    unsigned char ct = (comp==1)?0:(comp==2)?4:(comp==3)?2:6;
    ihdr[9]=ct; ihdr[10]=0; ihdr[11]=0; ihdr[12]=0;
    if (!stbi__chunk(&out, "IHDR", ihdr, 13)) { free(z.p); free(out.p); return 0; }

    /* IDAT */
    if (!stbi__chunk(&out, "IDAT", z.p, (unsigned int)z.len)) { free(z.p); free(out.p); return 0; }
    free(z.p);

    /* IEND */
    if (!stbi__chunk(&out, "IEND", NULL, 0)) { free(out.p); return 0; }

    FILE *f = fopen(filename, "wb");
    if (!f) { free(out.p); return 0; }
    size_t wr = fwrite(out.p, 1, out.len, f);
    fclose(f);
    free(out.p);
    return wr == out.len ? 1 : 0;
}

#endif /* STB_IMAGE_WRITE_IMPLEMENTATION */

#ifdef __cplusplus
}
#endif

#endif /* STB_IMAGE_WRITE_H_MINI */
