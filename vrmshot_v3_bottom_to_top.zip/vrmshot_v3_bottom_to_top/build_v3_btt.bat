@echo off
setlocal
where gcc >nul 2>nul
if errorlevel 1 (
  echo [ERROR] gcc not found. Run from w64devkit terminal.
  pause & exit /b 1
)
echo [1/2] Resources...
windres vrmshot_v3_btt.rc -o vrmshot_v3_btt_res.o
if errorlevel 1 ( echo [ERROR] windres failed. & pause & exit /b 1 )
echo [2/2] Compiling...
gcc -O2 -o vrmshot_v3_bottom_to_top.exe vrmshot_v3_bottom_to_top.c vrmshot_v3_btt_res.o -lgdi32 -luser32 -lcomctl32 -mwindows -static
if errorlevel 1 ( echo [ERROR] gcc failed. & pause & exit /b 1 )
echo.
echo Done: vrmshot_v3_bottom_to_top.exe
pause
